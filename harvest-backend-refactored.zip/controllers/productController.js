const { sql, poolPromise } = require('../db');

async function createProduct(req, res) {
  try {
    const { ProductName, Description, Price, StockQuantity, CategoryId, images } = req.body;
    const userId = req.user.UserId;
    const pool = await poolPromise;

    const result = await pool.request()
      .input('FarmerId', sql.Int, userId)
      .input('CategoryId', sql.Int, CategoryId)
      .input('ProductName', sql.NVarChar, ProductName)
      .input('Description', sql.NVarChar, Description)
      .input('Price', sql.Decimal(10,2), Price)
      .input('StockQuantity', sql.Int, StockQuantity)
      .query('INSERT INTO Products (FarmerId, CategoryId, ProductName, Description, Price, StockQuantity) OUTPUT INSERTED.ProductId VALUES (@FarmerId, @CategoryId, @ProductName, @Description, @Price, @StockQuantity)');

    const productId = result.recordset[0].ProductId;

    if (images && images.length > 0) {
      for (const url of images) {
        await pool.request()
          .input('ProductId', sql.Int, productId)
          .input('ImageUrl', sql.NVarChar, url)
          .query('INSERT INTO ProductImages (ProductId, ImageUrl) VALUES (@ProductId, @ImageUrl)');
      }
    }

    res.json({ message: 'Product created successfully', productId });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

async function getProducts(req, res) {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM Products');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { createProduct, getProducts };