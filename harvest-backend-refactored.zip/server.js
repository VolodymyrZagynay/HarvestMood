const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { sql, poolPromise } = require('./db');

const authController = require('./controllers/authController');
const productController = require('./controllers/productController');
const orderController = require('./controllers/orderController');
const reviewController = require('./controllers/reviewController');
const categoryController = require('./controllers/categoryController');

const { authenticateToken } = require('./middlewares/authMiddleware');
const { authorizeRole } = require('./middlewares/roleMiddleware');
const { upload } = require('./middlewares/uploadMiddleware');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Auth
app.post('/api/register', authController.register);
app.post('/api/login', authController.login);

// Products
app.post('/api/products', authenticateToken, authorizeRole('Farmer'), productController.createProduct);
app.get('/api/products', productController.getProducts);

// Orders
app.post('/api/orders', authenticateToken, orderController.createOrder);
app.get('/api/orders', authenticateToken, orderController.getOrders);

// Reviews
app.post('/api/reviews', authenticateToken, reviewController.createReview);
app.get('/api/reviews/:productId', reviewController.getReviews);

// Categories
app.get('/api/categories', categoryController.getCategories);

const PORT = process.env.PORT || 4000;
app.listen(PORT, async () => {
  try {
    const pool = await poolPromise;
    console.log('Connected to MSSQL');
  } catch (err) {
    console.error('Database connection failed:', err);
  }
  console.log(`Server running on port ${PORT}`);
});